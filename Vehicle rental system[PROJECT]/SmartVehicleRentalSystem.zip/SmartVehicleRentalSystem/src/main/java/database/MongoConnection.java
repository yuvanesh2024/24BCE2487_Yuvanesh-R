package database;

import com.mongodb.MongoException;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

/**
 * MongoConnection
 * ----------------
 * Manages a single, shared connection to the MongoDB server for the entire
 * application lifecycle.
 *
 * This class is implemented using the Singleton design pattern so that no
 * matter how many services (AdminService, CustomerService, VehicleService,
 * RentalService, PaymentService) need database access, they all share the
 * exact same MongoClient instance instead of each opening its own
 * connection. Opening multiple MongoClient instances is wasteful and is
 * considered bad practice with the MongoDB Java Driver, since a single
 * MongoClient already manages an internal connection pool.
 */
public class MongoConnection {

    // Connection details for the local MongoDB instance (used with MongoDB Compass)
    private static final String CONNECTION_STRING = "mongodb://localhost:27017";
    private static final String DATABASE_NAME = "vehicle_rental_system";

    // The single instance of this class (Singleton pattern)
    private static MongoConnection instance;

    // The underlying driver objects
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoConnection() {
        try {
            this.mongoClient = MongoClients.create(CONNECTION_STRING);
            this.database = mongoClient.getDatabase(DATABASE_NAME);
            System.out.println("Successfully connected to MongoDB database: " + DATABASE_NAME);
        } catch (MongoException e) {
            System.err.println("Failed to connect to MongoDB: " + e.getMessage());
            // Re-throw as a runtime exception so the application does not
            // continue running with a broken/null database reference.
            throw new RuntimeException("Could not initialize MongoDB connection", e);
        }
    }
    public static synchronized MongoConnection getInstance() {
        if (instance == null) {
            instance = new MongoConnection();
        }
        return instance;
    }
    public MongoDatabase getDatabase() {
        return database;
    }
    public void closeConnection() {
        try {
            if (mongoClient != null) {
                mongoClient.close();
                System.out.println("MongoDB connection closed successfully.");
            }
        } catch (MongoException e) {
            System.err.println("Error while closing MongoDB connection: " + e.getMessage());
        } finally {
            instance = null;
        }
    }
}