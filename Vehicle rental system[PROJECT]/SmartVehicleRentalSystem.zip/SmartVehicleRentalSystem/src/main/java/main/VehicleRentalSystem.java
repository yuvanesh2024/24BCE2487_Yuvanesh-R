package main;
import database.MongoConnection;
import models.Admin;
import models.Customer;
import models.Payment;
import models.Rental;
import models.Vehicle;
import services.AdminService;
import services.CustomerService;
import services.PaymentService;
import services.RentalService;
import services.VehicleService;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;
public class VehicleRentalSystem {
    private static final Scanner scanner = new Scanner(System.in);
    private static final AdminService adminService = new AdminService();
    private static final CustomerService customerService = new CustomerService();
    private static final VehicleService vehicleService = new VehicleService();
    private static final RentalService rentalService = new RentalService();
    private static final PaymentService paymentService = new PaymentService();
    public static void main(String[] args) {
        runMainMenu();
    }
    private static void runMainMenu() {
        boolean exit = false;

        while (!exit) {
            printHeader("SMART VEHICLE RENTAL MANAGEMENT SYSTEM");
            System.out.println("1. Admin Login");
            System.out.println("2. Customer Register");
            System.out.println("3. Customer Login");
            System.out.println("4. Exit");

            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    adminLoginFlow();
                    break;
                case 2:
                    customerRegisterFlow();
                    break;
                case 3:
                    customerLoginFlow();
                    break;
                case 4:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-4.");
            }
        }

        shutdown();
    }
    private static void shutdown() {
        System.out.println("Closing MongoDB connection and exiting. Goodbye!");
        MongoConnection.getInstance().closeConnection();
        scanner.close();
    }
    private static void adminLoginFlow() {
        printHeader("ADMIN LOGIN");
        String username = readString("Username: ");
        String password = readString("Password: ");

        Admin admin = adminService.loginAdmin(username, password);
        if (admin != null) {
            adminDashboard(admin);
        }
    }
    private static void adminDashboard(Admin admin) {
        boolean logout = false;

        while (!logout) {
            printHeader("ADMIN DASHBOARD - " + admin.getUsername());
            System.out.println("1. Manage Vehicles");
            System.out.println("2. Manage Customers");
            System.out.println("3. Manage Rentals");
            System.out.println("4. Manage Payments");
            System.out.println("5. Logout");

            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    manageVehiclesMenu();
                    break;
                case 2:
                    manageCustomersMenu();
                    break;
                case 3:
                    manageRentalsMenu();
                    break;
                case 4:
                    managePaymentsMenu();
                    break;
                case 5:
                    logout = true;
                    System.out.println("Logged out of admin account.");
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-5.");
            }
        }
    }
    private static void manageVehiclesMenu() {
        boolean back = false;

        while (!back) {
            printHeader("MANAGE VEHICLES");
            System.out.println("1. Add Vehicle");
            System.out.println("2. View All Vehicles");
            System.out.println("3. Search Vehicle by ID");
            System.out.println("4. Search Vehicles by Type");
            System.out.println("5. Search Vehicles by Brand");
            System.out.println("6. Update Vehicle");
            System.out.println("7. Delete Vehicle");
            System.out.println("8. Mark Vehicle Available/Unavailable");
            System.out.println("9. Back");

            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    addVehicleFlow();
                    break;
                case 2:
                    vehicleService.viewAllVehicles();
                    break;
                case 3:
                    searchVehicleByIdFlow();
                    break;
                case 4:
                    searchVehiclesByTypeFlow();
                    break;
                case 5:
                    searchVehiclesByBrandFlow();
                    break;
                case 6:
                    updateVehicleFlow();
                    break;
                case 7:
                    deleteVehicleFlow();
                    break;
                case 8:
                    toggleVehicleAvailabilityFlow();
                    break;
                case 9:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-9.");
            }
        }
    }

    private static void addVehicleFlow() {
        printHeader("ADD VEHICLE");
        String name = readString("Vehicle Name: ");
        String type = readString("Vehicle Type (e.g. Car, Bike, SUV): ");
        String brand = readString("Brand: ");
        String model = readString("Model: ");
        double price = readDouble("Price Per Day: ");
        Vehicle vehicle = new Vehicle(null, name, type, brand, model, price, true);
        vehicleService.addVehicle(vehicle);
    }

    private static void searchVehicleByIdFlow() {
        String id = readString("Enter Vehicle ID: ");
        Vehicle vehicle = vehicleService.searchVehicleById(id);
        if (vehicle != null) {
            System.out.println(vehicle);
        }
    }

    private static void searchVehiclesByTypeFlow() {
        String type = readString("Enter Vehicle Type: ");
        printVehicleList(vehicleService.searchVehiclesByType(type));
    }

    private static void searchVehiclesByBrandFlow() {
        String brand = readString("Enter Brand: ");
        printVehicleList(vehicleService.searchVehiclesByBrand(brand));
    }

    private static void printVehicleList(List<Vehicle> vehicles) {
        for (Vehicle vehicle : vehicles) {
            System.out.println(vehicle);
        }
    }

    private static void updateVehicleFlow() {
        String id = readString("Enter Vehicle ID to update: ");
        Vehicle existing = vehicleService.searchVehicleById(id);

        if (existing == null) {
            return;
        }

        System.out.println("Press Enter on any field to keep its current value.");
        String name = readStringOrKeep("Vehicle Name", existing.getVehicleName());
        String type = readStringOrKeep("Vehicle Type", existing.getVehicleType());
        String brand = readStringOrKeep("Brand", existing.getBrand());
        String model = readStringOrKeep("Model", existing.getModel());
        double price = readDoubleOrKeep("Price Per Day", existing.getPricePerDay());
        Vehicle updated = new Vehicle(id, name, type, brand, model, price, existing.isAvailabilityStatus());
        vehicleService.updateVehicle(id, updated);
    }

    private static void deleteVehicleFlow() {
        String id = readString("Enter Vehicle ID to delete: ");
        if (confirm("Are you sure you want to delete vehicle " + id + "?")) {
            vehicleService.deleteVehicle(id);
        } else {
            System.out.println("Deletion cancelled.");
        }
    }

    private static void toggleVehicleAvailabilityFlow() {
        String id = readString("Enter Vehicle ID: ");
        String statusInput = readString("Mark as (available/unavailable): ");
        boolean status = statusInput.equalsIgnoreCase("available");
        vehicleService.updateAvailabilityStatus(id, status);
    }
    private static void manageCustomersMenu() {
        boolean back = false;

        while (!back) {
            printHeader("MANAGE CUSTOMERS");
            System.out.println("1. View All Customers");
            System.out.println("2. Search Customer by ID");
            System.out.println("3. Delete Customer");
            System.out.println("4. Back");

            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    customerService.viewAllCustomers();
                    break;
                case 2:
                    searchCustomerByIdFlow();
                    break;
                case 3:
                    deleteCustomerFlow();
                    break;
                case 4:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-4.");
            }
        }
    }

    private static void searchCustomerByIdFlow() {
        String id = readString("Enter Customer ID: ");
        Customer customer = customerService.searchCustomerById(id);
        if (customer != null) {
            System.out.println(customer);
        }
    }

    private static void deleteCustomerFlow() {
        String id = readString("Enter Customer ID to delete: ");
        if (confirm("Are you sure you want to delete customer " + id + "?")) {
            customerService.deleteCustomer(id);
        } else {
            System.out.println("Deletion cancelled.");
        }
    }
    private static void manageRentalsMenu() {
        boolean back = false;

        while (!back) {
            printHeader("MANAGE RENTALS");
            System.out.println("1. View All Rentals");
            System.out.println("2. Search Rental by ID");
            System.out.println("3. View Rentals by Customer ID");
            System.out.println("4. Complete Rental (Mark Returned)");
            System.out.println("5. Delete Rental");
            System.out.println("6. Back");

            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    rentalService.viewAllRentals();
                    break;
                case 2:
                    searchRentalByIdFlow();
                    break;
                case 3:
                    searchRentalsByCustomerIdFlow();
                    break;
                case 4:
                    completeRentalFlow();
                    break;
                case 5:
                    deleteRentalFlow();
                    break;
                case 6:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-6.");
            }
        }
    }

    private static void searchRentalByIdFlow() {
        String id = readString("Enter Rental ID: ");
        Rental rental = rentalService.searchRentalById(id);
        if (rental != null) {
            System.out.println(rental);
        }
    }

    private static void searchRentalsByCustomerIdFlow() {
        String customerId = readString("Enter Customer ID: ");
        for (Rental rental : rentalService.searchRentalsByCustomerId(customerId)) {
            System.out.println(rental);
        }
    }

    private static void completeRentalFlow() {
        String id = readString("Enter Rental ID to mark as completed: ");
        rentalService.completeRental(id);
    }

    private static void deleteRentalFlow() {
        String id = readString("Enter Rental ID to delete: ");
        if (confirm("Are you sure you want to delete rental " + id + "?")) {
            rentalService.deleteRental(id);
        } else {
            System.out.println("Deletion cancelled.");
        }
    }
    private static void managePaymentsMenu() {
        boolean back = false;

        while (!back) {
            printHeader("MANAGE PAYMENTS");
            System.out.println("1. View All Payments");
            System.out.println("2. Search Payment by ID");
            System.out.println("3. Search Payments by Rental ID");
            System.out.println("4. Update Payment Status");
            System.out.println("5. Delete Payment");
            System.out.println("6. Back");

            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    paymentService.viewAllPayments();
                    break;
                case 2:
                    searchPaymentByIdFlow();
                    break;
                case 3:
                    searchPaymentsByRentalIdFlow();
                    break;
                case 4:
                    updatePaymentStatusFlow();
                    break;
                case 5:
                    deletePaymentFlow();
                    break;
                case 6:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-6.");
            }
        }
    }

    private static void searchPaymentByIdFlow() {
        String id = readString("Enter Payment ID: ");
        Payment payment = paymentService.searchPaymentById(id);
        if (payment != null) {
            System.out.println(payment);
        }
    }

    private static void searchPaymentsByRentalIdFlow() {
        String rentalId = readString("Enter Rental ID: ");
        for (Payment payment : paymentService.searchPaymentsByRentalId(rentalId)) {
            System.out.println(payment);
        }
    }

    private static void updatePaymentStatusFlow() {
        String id = readString("Enter Payment ID: ");
        String status = readString("Enter new status (PENDING/COMPLETED/FAILED): ");
        paymentService.updatePaymentStatus(id, status);
    }

    private static void deletePaymentFlow() {
        String id = readString("Enter Payment ID to delete: ");
        if (confirm("Are you sure you want to delete payment " + id + "?")) {
            paymentService.deletePayment(id);
        } else {
            System.out.println("Deletion cancelled.");
        }
    }
    private static void customerRegisterFlow() {
        printHeader("CUSTOMER REGISTRATION");
        String name = readString("Full Name: ");
        String email = readString("Email: ");
        String phone = readString("Phone Number (10 digits): ");
        String license = readString("Driving License Number: ");
        String username = readString("Choose a Username: ");
        String password = readString("Choose a Password (min 8 chars, upper+lower+digit): ");

        // customerId is left null; CustomerService generates one automatically.
        Customer customer = new Customer(null, name, email, phone, license, username, password);
        customerService.registerCustomer(customer);
    }

    private static void customerLoginFlow() {
        printHeader("CUSTOMER LOGIN");
        String username = readString("Username: ");
        String password = readString("Password: ");

        Customer customer = customerService.loginCustomer(username, password);
        if (customer != null) {
            customerDashboard(customer);
        }
    }

    private static void customerDashboard(Customer customer) {
        boolean logout = false;

        while (!logout) {
            printHeader("CUSTOMER DASHBOARD - " + customer.getName());
            System.out.println("1. Browse Vehicles");
            System.out.println("2. Rent a Vehicle");
            System.out.println("3. Return a Vehicle");
            System.out.println("4. View My Rental History");
            System.out.println("5. View My Payment History");
            System.out.println("6. Logout");

            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    browseVehiclesMenu();
                    break;
                case 2:
                    rentVehicleFlow(customer);
                    break;
                case 3:
                    returnVehicleFlow(customer);
                    break;
                case 4:
                    viewRentalHistoryFlow(customer);
                    break;
                case 5:
                    viewPaymentHistoryFlow(customer);
                    break;
                case 6:
                    logout = true;
                    System.out.println("Logged out of customer account.");
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-6.");
            }
        }
    }

    private static void browseVehiclesMenu() {
        boolean back = false;

        while (!back) {
            printHeader("BROWSE VEHICLES");
            System.out.println("1. View All Vehicles");
            System.out.println("2. Search by Type");
            System.out.println("3. Search by Brand");
            System.out.println("4. Back");

            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    vehicleService.viewAllVehicles();
                    break;
                case 2:
                    searchVehiclesByTypeFlow();
                    break;
                case 3:
                    searchVehiclesByBrandFlow();
                    break;
                case 4:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1-4.");
            }
        }
    }
    private static void rentVehicleFlow(Customer customer) {
        printHeader("RENT A VEHICLE");
        String vehicleId = readString("Enter Vehicle ID to rent: ");
        LocalDate rentalDate = readDate("Enter rental start date");
        int numberOfDays = readInt("Enter number of rental days: ");

        Rental rental = new Rental();
        rental.setCustomerId(customer.getCustomerId());
        rental.setVehicleId(vehicleId);
        rental.setRentalDate(rentalDate);
        rental.setNumberOfDays(numberOfDays);

        boolean success = rentalService.createRental(rental);

        if (success) {
            String wantsToPay = readString("Would you like to pay now? (yes/no): ");
            if (wantsToPay.equalsIgnoreCase("yes")) {
                makePaymentFlow(rental);
            } else {
                System.out.println("You can pay later using Rental ID: " + rental.getRentalId());
            }
        }
    }
    private static void makePaymentFlow(Rental rental) {
        System.out.println("Select payment method:");
        System.out.println("1. UPI");
        System.out.println("2. CARD");
        System.out.println("3. CASH");
        int choice = readInt("Enter choice: ");

        String method;
        switch (choice) {
            case 1:
                method = "UPI";
                break;
            case 2:
                method = "CARD";
                break;
            case 3:
                method = "CASH";
                break;
            default:
                System.out.println("Invalid choice. Payment cancelled.");
                return;
        }

        Payment payment = new Payment();
        payment.setRentalId(rental.getRentalId());
        payment.setAmount(rental.getTotalAmount());
        payment.setPaymentDate(LocalDate.now());
        payment.setPaymentMethod(method);
        payment.setPaymentStatus("COMPLETED");

        paymentService.addPayment(payment);
    }

    private static void returnVehicleFlow(Customer customer) {
        printHeader("RETURN A VEHICLE");
        String rentalId = readString("Enter Rental ID to return: ");
        Rental rental = rentalService.searchRentalById(rentalId);

        if (rental == null) {
            return; // "not found" message was already printed by the service
        }

        if (!rental.getCustomerId().equals(customer.getCustomerId())) {
            System.out.println("This rental does not belong to your account.");
            return;
        }

        rentalService.completeRental(rentalId);
    }

    private static void viewRentalHistoryFlow(Customer customer) {
        printHeader("MY RENTAL HISTORY");
        List<Rental> rentals = rentalService.searchRentalsByCustomerId(customer.getCustomerId());
        for (Rental rental : rentals) {
            System.out.println(rental);
        }
    }
    private static void viewPaymentHistoryFlow(Customer customer) {
        printHeader("MY PAYMENT HISTORY");
        List<Rental> rentals = rentalService.searchRentalsByCustomerId(customer.getCustomerId());

        for (Rental rental : rentals) {
            List<Payment> payments = paymentService.searchPaymentsByRentalId(rental.getRentalId());
            for (Payment payment : payments) {
                System.out.println(payment);
            }
        }
    }
    private static void printHeader(String title) {
        System.out.println();
        System.out.println("===== " + title + " =====");
    }
    private static boolean confirm(String message) {
        String response = readString(message + " (yes/no): ");
        return response.equalsIgnoreCase("yes");
    }
    private static String readString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }
    private static String readStringOrKeep(String label, String currentValue) {
        System.out.print(label + " [" + currentValue + "] (press Enter to keep): ");
        String input = scanner.nextLine().trim();
        return input.isEmpty() ? currentValue : input;
    }
    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a whole number.");
            }
        }
    }
    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                return Double.parseDouble(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }
    }
    private static double readDoubleOrKeep(String label, double currentValue) {
        System.out.print(label + " [" + currentValue + "] (press Enter to keep): ");
        String input = scanner.nextLine().trim();
        if (input.isEmpty()) {
            return currentValue;
        }
        try {
            return Double.parseDouble(input);
        } catch (NumberFormatException e) {
            System.out.println("Invalid number entered. Keeping current value.");
            return currentValue;
        }
    }
    private static LocalDate readDate(String prompt) {
        while (true) {
            System.out.print(prompt + " (YYYY-MM-DD, press Enter for today): ");
            String input = scanner.nextLine().trim();

            if (input.isEmpty()) {
                return LocalDate.now();
            }

            try {
                return LocalDate.parse(input);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Please use YYYY-MM-DD.");
            }
        }
    }
}