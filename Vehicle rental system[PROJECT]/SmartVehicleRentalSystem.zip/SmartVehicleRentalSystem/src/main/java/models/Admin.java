package models;

/**
 * Admin
 * -----
 * Represents an administrator of the Smart Vehicle Rental Management
 * System. Each Admin document stored in the "admins" collection in
 * MongoDB is mapped to and from an instance of this class.
 *
 * This is a plain model (POJO) class � it holds data only and contains
 * no database or business logic, keeping it fully decoupled from
 * MongoConnection and AdminService.
 */
public class Admin{

    // Unique identifier for the admin (e.g. "ADM001")
    private String adminId;

    // Login username
    private String username;

    // Login password
    private String password;
    public Admin() {
    }
    public Admin(String adminId, String username, String password) {
        this.adminId = adminId;
        this.username = username;
        this.password = password;
    }
    public String getAdminId() {
        return adminId;
    }
    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    @Override
    public String toString() {
        return "Admin{" +
                "adminId='" + adminId + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}