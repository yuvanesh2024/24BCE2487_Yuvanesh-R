package models;

/**
 * Customer
 * --------
 * Represents a registered customer of the Smart Vehicle Rental
 * Management System. Each Customer document stored in the "customers"
 * collection in MongoDB is mapped to and from an instance of this class.
 *
 * This is a plain model (POJO) class � it holds data only and contains
 * no database or business logic, keeping it fully decoupled from
 * MongoConnection and CustomerService.
 */
public class Customer{

    // Unique identifier for the customer (e.g. "CUST001")
    private String customerId;

    // Full name of the customer
    private String name;

    // Email address
    private String email;

    // Contact phone number
    private String phoneNumber;

    // Driving license number, required to rent a vehicle
    private String licenseNumber;

    // Login username
    private String username;

    // Login password
    private String password;
    public Customer() {
    }
    public Customer(String customerId, String name, String email, String phoneNumber,
                     String licenseNumber, String username, String password) {
        this.customerId = customerId;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.licenseNumber = licenseNumber;
        this.username = username;
        this.password = password;
    }
    public String getCustomerId() {
        return customerId;
    }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public String getLicenseNumber() {
        return licenseNumber;
    }
    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    @Override
    public String toString() {
        return "Customer{" +
                "customerId='" + customerId + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", licenseNumber='" + licenseNumber + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}