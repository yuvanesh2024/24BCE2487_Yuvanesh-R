package models;

import java.time.LocalDate;

/**
 * Payment
 * -------
 * Represents a single payment transaction in the Smart Vehicle Rental
 * Management System, linked to a specific rental. Each Payment document
 * stored in the "payments" collection in MongoDB is mapped to and from
 * an instance of this class.
 *
 * This is a plain model (POJO) class � it holds data only and contains
 * no database or business logic, keeping it fully decoupled from
 * MongoConnection and PaymentService.
 *
 * Valid values for {@code paymentMethod} are:
 * <ul>
 *     <li>"UPI"</li>
 *     <li>"CARD"</li>
 *     <li>"CASH"</li>
 * </ul>
 *
 * Valid values for {@code paymentStatus} are:
 * <ul>
 *     <li>"PENDING" � payment has been initiated but not confirmed</li>
 *     <li>"COMPLETED" � payment was successful</li>
 *     <li>"FAILED" � payment did not go through</li>
 * </ul>
 */
public class Payment{

    // Unique identifier for the payment transaction (e.g. "PAY001")
    private String paymentId;

    // Identifier of the rental this payment is associated with
    private String rentalId;

    // Amount paid
    private double amount;

    // Date the payment was made
    private LocalDate paymentDate;

    // Method used to pay: "UPI", "CARD", or "CASH"
    private String paymentMethod;

    // Current status of the payment: "PENDING", "COMPLETED", or "FAILED"
    private String paymentStatus;
    public Payment() {
    }
    public Payment(String paymentId, String rentalId, double amount, LocalDate paymentDate,
                    String paymentMethod, String paymentStatus) {
        this.paymentId = paymentId;
        this.rentalId = rentalId;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.paymentMethod = paymentMethod;
        this.paymentStatus = paymentStatus;
    }
    public String getPaymentId() {
        return paymentId;
    }
    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }
    public String getRentalId() {
        return rentalId;
    }
    public void setRentalId(String rentalId) {
        this.rentalId = rentalId;
    }
    public double getAmount() {
        return amount;
    }
    public void setAmount(double amount) {
        this.amount = amount;
    }
    public LocalDate getPaymentDate() {
        return paymentDate;
    }
    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = paymentDate;
    }
    public String getPaymentMethod() {
        return paymentMethod;
    }
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
    public String getPaymentStatus() {
        return paymentStatus;
    }
    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
    @Override
    public String toString() {
        return "Payment{" +
                "paymentId='" + paymentId + '\'' +
                ", rentalId='" + rentalId + '\'' +
                ", amount=" + amount +
                ", paymentDate=" + paymentDate +
                ", paymentMethod='" + paymentMethod + '\'' +
                ", paymentStatus='" + paymentStatus + '\'' +
                '}';
    }
}