package models;

import java.time.LocalDate;

/**
 * Rental
 * ------
 * Represents a single vehicle rental transaction in the Smart Vehicle
 * Rental Management System. Each Rental document stored in the
 * "rentals" collection in MongoDB is mapped to and from an instance of
 * this class.
 *
 * This is a plain model (POJO) class � it holds data only and contains
 * no database or business logic, keeping it fully decoupled from
 * MongoConnection and RentalService.
 *
 * Valid values for {@code rentalStatus} are:
 * <ul>
 *     <li>"ACTIVE" � the vehicle has been booked and not yet returned</li>
 *     <li>"COMPLETED" � the vehicle has been returned</li>
 * </ul>
 */
public class Rental {

    // Unique identifier for the rental transaction (e.g. "RENT001")
    private String rentalId;

    // Identifier of the customer who made the booking
    private String customerId;

    // Identifier of the vehicle that was booked
    private String vehicleId;

    // Date the rental period starts
    private LocalDate rentalDate;

    // Number of days the vehicle is rented for
    private int numberOfDays;

    // Total cost of the rental (pricePerDay * numberOfDays, plus any fine)
    private double totalAmount;

    // Current status of the rental: "ACTIVE" or "COMPLETED"
    private String rentalStatus;
    public Rental() {
    }
    public Rental(String rentalId, String customerId, String vehicleId, LocalDate rentalDate,
                   int numberOfDays, double totalAmount, String rentalStatus) {
        this.rentalId = rentalId;
        this.customerId = customerId;
        this.vehicleId = vehicleId;
        this.rentalDate = rentalDate;
        this.numberOfDays = numberOfDays;
        this.totalAmount = totalAmount;
        this.rentalStatus = rentalStatus;
    }
    public String getRentalId() {
        return rentalId;
    }
    public void setRentalId(String rentalId) {
        this.rentalId = rentalId;
    }
    public String getCustomerId() {
        return customerId;
    }
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    public String getVehicleId() {
        return vehicleId;
    }
    public void setVehicleId(String vehicleId) {
        this.vehicleId = vehicleId;
    }
    public LocalDate getRentalDate() {
        return rentalDate;
    }
    public void setRentalDate(LocalDate rentalDate) {
        this.rentalDate = rentalDate;
    }
    public int getNumberOfDays() {
        return numberOfDays;
    }
    public void setNumberOfDays(int numberOfDays) {
        this.numberOfDays = numberOfDays;
    }
    public double getTotalAmount() {
        return totalAmount;
    }
    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }
    public String getRentalStatus() {
        return rentalStatus;
    }
    public void setRentalStatus(String rentalStatus) {
        this.rentalStatus = rentalStatus;
    }
    @Override
    public String toString() {
        return "Rental{" +
                "rentalId='" + rentalId + '\'' +
                ", customerId='" + customerId + '\'' +
                ", vehicleId='" + vehicleId + '\'' +
                ", rentalDate=" + rentalDate +
                ", numberOfDays=" + numberOfDays +
                ", totalAmount=" + totalAmount +
                ", rentalStatus='" + rentalStatus + '\'' +
                '}';
    }
}