package models;

/**
 * Vehicle
 * -------
 * Represents a rentable vehicle in the Smart Vehicle Rental Management
 * System. Each Vehicle document stored in the "vehicles" collection in
 * MongoDB is mapped to and from an instance of this class.
 *
 * This is a plain model (POJO) class � it holds data only and contains
 * no database or business logic, keeping it fully decoupled from
 * MongoConnection and VehicleService.
 */
public class Vehicle{

    // Unique identifier for the vehicle (e.g. "VEH001")
    private String vehicleId;

    // Display name of the vehicle (e.g. "Swift Dzire")
    private String vehicleName;

    // Category of the vehicle (e.g. "Car", "Bike", "SUV")
    private String vehicleType;

    // Manufacturer/brand (e.g. "Maruti Suzuki")
    private String brand;

    // Specific model name (e.g. "Dzire VXi")
    private String model;

    // Rental price charged per day
    private double pricePerDay;

    // true if the vehicle is currently available for booking, false otherwise
    private boolean availabilityStatus;
    public Vehicle() {
    }
    public Vehicle(String vehicleId, String vehicleName, String vehicleType, String brand,
                    String model, double pricePerDay, boolean availabilityStatus) {
        this.vehicleId = vehicleId;
        this.vehicleName = vehicleName;
        this.vehicleType = vehicleType;
        this.brand = brand;
        this.model = model;
        this.pricePerDay = pricePerDay;
        this.availabilityStatus = availabilityStatus;
    }
    public String getVehicleId() {
        return vehicleId;
    }
    public void setVehicleId(String vehicleId) {
        this.vehicleId = vehicleId;
    }
    public String getVehicleName() {
        return vehicleName;
    }
    public void setVehicleName(String vehicleName) {
        this.vehicleName = vehicleName;
    }
    public String getVehicleType() {
        return vehicleType;
    }
    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }
    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public double getPricePerDay() {
        return pricePerDay;
    }
    public void setPricePerDay(double pricePerDay) {
        this.pricePerDay = pricePerDay;
    }
    public boolean isAvailabilityStatus() {
        return availabilityStatus;
    }
    public void setAvailabilityStatus(boolean availabilityStatus) {
        this.availabilityStatus = availabilityStatus;
    }
    @Override
    public String toString() {
        return "Vehicle{" +
                "vehicleId='" + vehicleId + '\'' +
                ", vehicleName='" + vehicleName + '\'' +
                ", vehicleType='" + vehicleType + '\'' +
                ", brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                ", pricePerDay=" + pricePerDay +
                ", availabilityStatus=" + availabilityStatus +
                '}';
    }
}