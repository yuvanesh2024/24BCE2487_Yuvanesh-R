package services;

import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.DeleteResult;
import database.MongoConnection;
import models.Admin;
import org.bson.Document;
import utils.IDGenerator;

import java.util.ArrayList;
import java.util.List;

/**
 * AdminService
 * ------------
 * Handles all business logic and MongoDB operations related to
 * administrators. This class is the only place in the application
 * that talks directly to the "admins" collection � the Main menu and
 * other services never touch the MongoCollection themselves, they go
 * through these methods.
 *
 * Responsibilities:
 * <ul>
 *     <li>Registering new admins, with unique-username enforcement</li>
 *     <li>Authenticating admin login</li>
 *     <li>Viewing, searching, and deleting admin records</li>
 *     <li>Converting between {@link Admin} objects and MongoDB {@link Document} objects</li>
 * </ul>
 */
public class AdminService{

    private static final String COLLECTION_NAME = "admins";
    private final MongoCollection<Document> adminCollection;
    public AdminService() {
        this.adminCollection = MongoConnection.getInstance().getDatabase().getCollection(COLLECTION_NAME);
    }
    public boolean registerAdmin(Admin admin) {
        try {
            if (isUsernameTaken(admin.getUsername())) {
                System.out.println("Username already exists. Please choose a different username.");
                return false;
            }

            if (admin.getAdminId() == null || admin.getAdminId().trim().isEmpty()) {
                admin.setAdminId(IDGenerator.generateAdminId());
            }

            Document document = adminToDocument(admin);
            adminCollection.insertOne(document);

            System.out.println("Admin registered successfully with ID: " + admin.getAdminId());
            return true;

        } catch (MongoException e) {
            System.err.println("Error registering admin: " + e.getMessage());
            return false;
        }
    }
    public Admin loginAdmin(String username, String password) {
        try {
            Document document = adminCollection.find(Filters.eq("username", username)).first();

            if (document == null) {
                System.out.println("No admin account found with username: " + username);
                return null;
            }

            Admin admin = documentToAdmin(document);

            if (!admin.getPassword().equals(password)) {
                System.out.println("Incorrect password.");
                return null;
            }

            System.out.println("Admin login successful. Welcome, " + admin.getUsername() + "!");
            return admin;

        } catch (MongoException e) {
            System.err.println("Error during admin login: " + e.getMessage());
            return null;
        }
    }
    public void viewAllAdmins() {
        try {
            List<Admin> admins = new ArrayList<>();
            FindIterable<Document> results = adminCollection.find();

            for (Document document : results) {
                admins.add(documentToAdmin(document));
            }

            if (admins.isEmpty()) {
                System.out.println("No admins found in the system.");
                return;
            }

            System.out.println("----- All Admins -----");
            for (Admin admin : admins) {
                System.out.println(admin);
            }

        } catch (MongoException e) {
            System.err.println("Error retrieving admins: " + e.getMessage());
        }
    }
    public Admin searchAdminById(String adminId) {
        try {
            Document document = adminCollection.find(Filters.eq("adminId", adminId)).first();

            if (document == null) {
                System.out.println("No admin found with ID: " + adminId);
                return null;
            }

            return documentToAdmin(document);

        } catch (MongoException e) {
            System.err.println("Error searching admin by ID: " + e.getMessage());
            return null;
        }
    }
    public boolean deleteAdmin(String adminId) {
        try {
            DeleteResult result = adminCollection.deleteOne(Filters.eq("adminId", adminId));

            if (result.getDeletedCount() == 0) {
                System.out.println("No admin found with ID: " + adminId);
                return false;
            }

            System.out.println("Admin deleted successfully: " + adminId);
            return true;

        } catch (MongoException e) {
            System.err.println("Error deleting admin: " + e.getMessage());
            return false;
        }
    }
    private boolean isUsernameTaken(String username) {
        Document existing = adminCollection.find(Filters.eq("username", username)).first();
        return existing != null;
    }
    private Document adminToDocument(Admin admin) {
        return new Document("adminId", admin.getAdminId())
                .append("username", admin.getUsername())
                .append("password", admin.getPassword());
    }
    private Admin documentToAdmin(Document document) {
        Admin admin = new Admin();
        admin.setAdminId(document.getString("adminId"));
        admin.setUsername(document.getString("username"));
        admin.setPassword(document.getString("password"));
        return admin;
    }
}