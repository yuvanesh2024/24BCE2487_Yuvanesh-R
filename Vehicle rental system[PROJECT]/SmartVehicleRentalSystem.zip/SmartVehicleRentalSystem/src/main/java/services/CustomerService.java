package services;

import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.DeleteResult;
import database.MongoConnection;
import models.Customer;
import org.bson.Document;
import utils.IDGenerator;
import utils.InputValidator;

import java.util.ArrayList;
import java.util.List;

/**
 * CustomerService
 * ---------------
 * Handles all business logic and MongoDB operations related to
 * customers. This class is the only place in the application that
 * talks directly to the "customers" collection � the Main menu and
 * other services never touch the MongoCollection themselves, they go
 * through these methods.
 *
 * Responsibilities:
 * <ul>
 *     <li>Registering new customers, with full input validation</li>
 *     <li>Authenticating customer login</li>
 *     <li>Viewing, searching, and deleting customer records</li>
 *     <li>Converting between {@link Customer} objects and MongoDB {@link Document} objects</li>
 * </ul>
 */
public class CustomerService{

    private static final String COLLECTION_NAME = "customers";
    private final MongoCollection<Document> customerCollection;
    public CustomerService() {
        this.customerCollection = MongoConnection.getInstance().getDatabase().getCollection(COLLECTION_NAME);
    }
    public boolean registerCustomer(Customer customer) {
        try {
            if (!InputValidator.validateEmail(customer.getEmail())) {
                System.out.println("Invalid email format.");
                return false;
            }

            if (!InputValidator.validatePhoneNumber(customer.getPhoneNumber())) {
                System.out.println("Invalid phone number. Must be exactly 10 digits.");
                return false;
            }

            if (!InputValidator.validatePassword(customer.getPassword())) {
                System.out.println("Weak password. Must be at least 8 characters long and include "
                        + "an uppercase letter, a lowercase letter, and a digit.");
                return false;
            }

            if (isUsernameTaken(customer.getUsername())) {
                System.out.println("Username already exists. Please choose a different username.");
                return false;
            }

            if (customer.getCustomerId() == null || customer.getCustomerId().trim().isEmpty()) {
                customer.setCustomerId(IDGenerator.generateCustomerId());
            }

            Document document = customerToDocument(customer);
            customerCollection.insertOne(document);

            System.out.println("Customer registered successfully with ID: " + customer.getCustomerId());
            return true;

        } catch (MongoException e) {
            System.err.println("Error registering customer: " + e.getMessage());
            return false;
        }
    }
    public Customer loginCustomer(String username, String password) {
        try {
            Document document = customerCollection.find(Filters.eq("username", username)).first();

            if (document == null) {
                System.out.println("No account found with username: " + username);
                return null;
            }

            Customer customer = documentToCustomer(document);

            if (!customer.getPassword().equals(password)) {
                System.out.println("Incorrect password.");
                return null;
            }

            System.out.println("Login successful. Welcome, " + customer.getName() + "!");
            return customer;

        } catch (MongoException e) {
            System.err.println("Error during customer login: " + e.getMessage());
            return null;
        }
    }
    public void viewAllCustomers() {
        try {
            List<Customer> customers = new ArrayList<>();
            FindIterable<Document> results = customerCollection.find();

            for (Document document : results) {
                customers.add(documentToCustomer(document));
            }

            if (customers.isEmpty()) {
                System.out.println("No customers found in the system.");
                return;
            }

            System.out.println("----- All Customers -----");
            for (Customer customer : customers) {
                System.out.println(customer);
            }

        } catch (MongoException e) {
            System.err.println("Error retrieving customers: " + e.getMessage());
        }
    }
    public Customer searchCustomerById(String customerId) {
        try {
            Document document = customerCollection.find(Filters.eq("customerId", customerId)).first();

            if (document == null) {
                System.out.println("No customer found with ID: " + customerId);
                return null;
            }

            return documentToCustomer(document);

        } catch (MongoException e) {
            System.err.println("Error searching customer by ID: " + e.getMessage());
            return null;
        }
    }
    public boolean deleteCustomer(String customerId) {
        try {
            DeleteResult result = customerCollection.deleteOne(Filters.eq("customerId", customerId));

            if (result.getDeletedCount() == 0) {
                System.out.println("No customer found with ID: " + customerId);
                return false;
            }

            System.out.println("Customer deleted successfully: " + customerId);
            return true;

        } catch (MongoException e) {
            System.err.println("Error deleting customer: " + e.getMessage());
            return false;
        }
    }
    private boolean isUsernameTaken(String username) {
        Document existing = customerCollection.find(Filters.eq("username", username)).first();
        return existing != null;
    }
    private Document customerToDocument(Customer customer) {
        return new Document("customerId", customer.getCustomerId())
                .append("name", customer.getName())
                .append("email", customer.getEmail())
                .append("phoneNumber", customer.getPhoneNumber())
                .append("licenseNumber", customer.getLicenseNumber())
                .append("username", customer.getUsername())
                .append("password", customer.getPassword());
    }
    private Customer documentToCustomer(Document document) {
        Customer customer = new Customer();
        customer.setCustomerId(document.getString("customerId"));
        customer.setName(document.getString("name"));
        customer.setEmail(document.getString("email"));
        customer.setPhoneNumber(document.getString("phoneNumber"));
        customer.setLicenseNumber(document.getString("licenseNumber"));
        customer.setUsername(document.getString("username"));
        customer.setPassword(document.getString("password"));
        return customer;
    }
}