package services;

import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import database.MongoConnection;
import models.Payment;
import org.bson.Document;
import utils.IDGenerator;
import utils.InputValidator;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * PaymentService
 * --------------
 * Handles all business logic and MongoDB operations related to
 * payments. This class is the only place in the application that
 * talks directly to the "payments" collection � the Main menu and
 * other services never touch the MongoCollection themselves, they go
 * through these methods.
 *
 * Responsibilities:
 * <ul>
 *     <li>Recording new payments after a successful booking</li>
 *     <li>Viewing and searching payment history</li>
 *     <li>Updating a payment's status ("PENDING", "COMPLETED", "FAILED")</li>
 *     <li>Converting between {@link Payment} objects and MongoDB {@link Document} objects</li>
 * </ul>
 */
public class PaymentService {

    private static final String COLLECTION_NAME = "payments";
    private static final Set<String> VALID_STATUSES = new java.util.HashSet<>(
            java.util.Arrays.asList("PENDING", "COMPLETED", "FAILED")
    );
    private final MongoCollection<Document> paymentCollection;
    public PaymentService() {
        this.paymentCollection = MongoConnection.getInstance().getDatabase().getCollection(COLLECTION_NAME);
    }
    public boolean addPayment(Payment payment) {
        try {
            if (!InputValidator.validatePositiveNumber(payment.getAmount())) {
                System.out.println("Invalid payment amount. Amount must be greater than zero.");
                return false;
            }

            if (payment.getPaymentId() == null || payment.getPaymentId().trim().isEmpty()) {
                payment.setPaymentId(IDGenerator.generatePaymentId());
            }

            Document document = paymentToDocument(payment);
            paymentCollection.insertOne(document);

            System.out.println("Payment recorded successfully with ID: " + payment.getPaymentId());
            return true;

        } catch (MongoException e) {
            System.err.println("Error recording payment: " + e.getMessage());
            return false;
        }
    }
    public void viewAllPayments() {
        try {
            List<Payment> payments = collectPayments(paymentCollection.find());

            if (payments.isEmpty()) {
                System.out.println("No payment records found in the system.");
                return;
            }

            System.out.println("----- All Payments -----");
            for (Payment payment : payments) {
                System.out.println(payment);
            }

        } catch (MongoException e) {
            System.err.println("Error retrieving payments: " + e.getMessage());
        }
    }
    public Payment searchPaymentById(String paymentId) {
        try {
            Document document = paymentCollection.find(Filters.eq("paymentId", paymentId)).first();

            if (document == null) {
                System.out.println("No payment found with ID: " + paymentId);
                return null;
            }

            return documentToPayment(document);

        } catch (MongoException e) {
            System.err.println("Error searching payment by ID: " + e.getMessage());
            return null;
        }
    }
    public List<Payment> searchPaymentsByRentalId(String rentalId) {
        try {
            List<Payment> payments = collectPayments(paymentCollection.find(Filters.eq("rentalId", rentalId)));

            if (payments.isEmpty()) {
                System.out.println("No payments found for rental ID: " + rentalId);
            }

            return payments;

        } catch (MongoException e) {
            System.err.println("Error searching payments by rental ID: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    public boolean updatePaymentStatus(String paymentId, String newStatus) {
        try {
            if (newStatus == null || !VALID_STATUSES.contains(newStatus.trim().toUpperCase())) {
                System.out.println("Invalid payment status. Allowed values are: PENDING, COMPLETED, FAILED.");
                return false;
            }

            UpdateResult result = paymentCollection.updateOne(
                    Filters.eq("paymentId", paymentId),
                    Updates.set("paymentStatus", newStatus.trim().toUpperCase())
            );

            if (result.getMatchedCount() == 0) {
                System.out.println("No payment found with ID: " + paymentId);
                return false;
            }

            System.out.println("Payment status updated successfully: " + paymentId + " -> " + newStatus.trim().toUpperCase());
            return true;

        } catch (MongoException e) {
            System.err.println("Error updating payment status: " + e.getMessage());
            return false;
        }
    }
    public boolean deletePayment(String paymentId) {
        try {
            DeleteResult result = paymentCollection.deleteOne(Filters.eq("paymentId", paymentId));

            if (result.getDeletedCount() == 0) {
                System.out.println("No payment found with ID: " + paymentId);
                return false;
            }

            System.out.println("Payment deleted successfully: " + paymentId);
            return true;

        } catch (MongoException e) {
            System.err.println("Error deleting payment: " + e.getMessage());
            return false;
        }
    }
    private List<Payment> collectPayments(FindIterable<Document> results) {
        List<Payment> payments = new ArrayList<>();
        for (Document document : results) {
            payments.add(documentToPayment(document));
        }
        return payments;
    }
    private Document paymentToDocument(Payment payment) {
        return new Document("paymentId", payment.getPaymentId())
                .append("rentalId", payment.getRentalId())
                .append("amount", payment.getAmount())
                .append("paymentDate", payment.getPaymentDate().toString())
                .append("paymentMethod", payment.getPaymentMethod())
                .append("paymentStatus", payment.getPaymentStatus());
    }
    private Payment documentToPayment(Document document) {
        Payment payment = new Payment();
        payment.setPaymentId(document.getString("paymentId"));
        payment.setRentalId(document.getString("rentalId"));
        payment.setAmount(document.getDouble("amount"));
        payment.setPaymentDate(LocalDate.parse(document.getString("paymentDate")));
        payment.setPaymentMethod(document.getString("paymentMethod"));
        payment.setPaymentStatus(document.getString("paymentStatus"));
        return payment;
    }
}