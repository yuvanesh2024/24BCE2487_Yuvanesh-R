package services;

import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import database.MongoConnection;
import models.Rental;
import models.Vehicle;
import org.bson.Document;
import utils.IDGenerator;
import utils.InputValidator;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * RentalService
 * -------------
 * Handles all business logic and MongoDB operations related to
 * rentals. This is the central service of the application: a rental
 * transaction touches three collections at once � "rentals",
 * "vehicles", and "customers" � so this class is responsible for
 * keeping all three consistent with one another.
 *
 * Responsibilities:
 * <ul>
 *     <li>Creating a new rental, after validating the customer and vehicle references and the vehicle's availability</li>
 *     <li>Automatically calculating totalAmount from the vehicle's daily price and the rental duration</li>
 *     <li>Marking a vehicle unavailable when it is rented, and available again when it is returned or its rental is deleted</li>
 *     <li>Viewing and searching rental records</li>
 *     <li>Converting between {@link Rental} objects and MongoDB {@link Document} objects</li>
 * </ul>
 *
 * Note on design: this class reads directly from the "customers" and
 * "vehicles" collections (rather than going through CustomerService or
 * VehicleService) purely to validate referential integrity � for
 * example, confirming a vehicleId actually exists before a rental is
 * created. It does not duplicate the full CRUD responsibilities of
 * those services.
 */
public class RentalService {

    private static final String RENTAL_COLLECTION_NAME = "rentals";
    private static final String CUSTOMER_COLLECTION_NAME = "customers";
    private static final String VEHICLE_COLLECTION_NAME = "vehicles";
    private final MongoCollection<Document> rentalCollection;
    private final MongoCollection<Document> customerCollection;
    private final MongoCollection<Document> vehicleCollection;
    public RentalService() {
        MongoDatabase database = MongoConnection.getInstance().getDatabase();
        this.rentalCollection = database.getCollection(RENTAL_COLLECTION_NAME);
        this.customerCollection = database.getCollection(CUSTOMER_COLLECTION_NAME);
        this.vehicleCollection = database.getCollection(VEHICLE_COLLECTION_NAME);
    }
    public boolean createRental(Rental rental) {
        try {
            if (!InputValidator.validatePositiveInteger(rental.getNumberOfDays())) {
                System.out.println("Invalid rental duration. Number of days must be greater than zero.");
                return false;
            }

            if (!customerExists(rental.getCustomerId())) {
                System.out.println("No customer found with ID: " + rental.getCustomerId());
                return false;
            }

            if (!vehicleExists(rental.getVehicleId())) {
                System.out.println("No vehicle found with ID: " + rental.getVehicleId());
                return false;
            }

            if (!isVehicleAvailable(rental.getVehicleId())) {
                System.out.println("Vehicle is currently unavailable: " + rental.getVehicleId());
                return false;
            }
            Vehicle vehicle = getVehicleById(rental.getVehicleId());
            double totalAmount = vehicle.getPricePerDay() * rental.getNumberOfDays();
            rental.setTotalAmount(totalAmount);

            rental.setRentalStatus("ACTIVE");

            if (rental.getRentalDate() == null) {
                rental.setRentalDate(LocalDate.now());
            }

            if (rental.getRentalId() == null || rental.getRentalId().trim().isEmpty()) {
                rental.setRentalId(IDGenerator.generateRentalId());
            }

            Document document = rentalToDocument(rental);
            rentalCollection.insertOne(document);

            updateVehicleAvailability(rental.getVehicleId(), false);

            System.out.println("Rental created successfully with ID: " + rental.getRentalId()
                    + ". Total amount: " + totalAmount);
            return true;

        } catch (MongoException e) {
            System.err.println("Error creating rental: " + e.getMessage());
            return false;
        }
    }
    public boolean completeRental(String rentalId) {
        try {
            Document rentalDocument = rentalCollection.find(Filters.eq("rentalId", rentalId)).first();

            if (rentalDocument == null) {
                System.out.println("No rental found with ID: " + rentalId);
                return false;
            }

            Rental rental = documentToRental(rentalDocument);

            if (!"ACTIVE".equals(rental.getRentalStatus())) {
                System.out.println("Rental is not active and cannot be completed: " + rentalId);
                return false;
            }

            UpdateResult result = rentalCollection.updateOne(
                    Filters.eq("rentalId", rentalId),
                    Updates.set("rentalStatus", "COMPLETED")
            );

            if (result.getMatchedCount() == 0) {
                System.out.println("Failed to update rental status: " + rentalId);
                return false;
            }

            boolean vehicleUpdated = updateVehicleAvailability(rental.getVehicleId(), true);
            if (!vehicleUpdated) {
                System.out.println("Warning: could not update availability for vehicle ID: "
                        + rental.getVehicleId() + " (it may have been deleted).");
            }

            System.out.println("Rental completed successfully: " + rentalId);
            return true;

        } catch (MongoException e) {
            System.err.println("Error completing rental: " + e.getMessage());
            return false;
        }
    }
    public void viewAllRentals() {
        try {
            List<Rental> rentals = collectRentals(rentalCollection.find());

            if (rentals.isEmpty()) {
                System.out.println("No rentals found in the system.");
                return;
            }

            System.out.println("----- All Rentals -----");
            for (Rental rental : rentals) {
                System.out.println(rental);
            }

        } catch (MongoException e) {
            System.err.println("Error retrieving rentals: " + e.getMessage());
        }
    }
    public Rental searchRentalById(String rentalId) {
        try {
            Document document = rentalCollection.find(Filters.eq("rentalId", rentalId)).first();

            if (document == null) {
                System.out.println("No rental found with ID: " + rentalId);
                return null;
            }

            return documentToRental(document);

        } catch (MongoException e) {
            System.err.println("Error searching rental by ID: " + e.getMessage());
            return null;
        }
    }
    public List<Rental> searchRentalsByCustomerId(String customerId) {
        try {
            List<Rental> rentals = collectRentals(rentalCollection.find(Filters.eq("customerId", customerId)));

            if (rentals.isEmpty()) {
                System.out.println("No rentals found for customer ID: " + customerId);
            }

            return rentals;

        } catch (MongoException e) {
            System.err.println("Error searching rentals by customer ID: " + e.getMessage());
            return new ArrayList<>();
        }
    }
    public boolean deleteRental(String rentalId) {
        try {
            Document rentalDocument = rentalCollection.find(Filters.eq("rentalId", rentalId)).first();

            if (rentalDocument == null) {
                System.out.println("No rental found with ID: " + rentalId);
                return false;
            }

            Rental rental = documentToRental(rentalDocument);

            if ("ACTIVE".equals(rental.getRentalStatus())) {
                boolean vehicleUpdated = updateVehicleAvailability(rental.getVehicleId(), true);
                if (!vehicleUpdated) {
                    System.out.println("Warning: could not update availability for vehicle ID: "
                            + rental.getVehicleId() + " (it may have been deleted).");
                }
            }

            DeleteResult result = rentalCollection.deleteOne(Filters.eq("rentalId", rentalId));

            if (result.getDeletedCount() == 0) {
                System.out.println("Failed to delete rental: " + rentalId);
                return false;
            }

            System.out.println("Rental deleted successfully: " + rentalId);
            return true;

        } catch (MongoException e) {
            System.err.println("Error deleting rental: " + e.getMessage());
            return false;
        }
    }
    private boolean customerExists(String customerId) {
        Document document = customerCollection.find(Filters.eq("customerId", customerId)).first();
        return document != null;
    }
    private boolean vehicleExists(String vehicleId) {
        return getVehicleById(vehicleId) != null;
    }
    private boolean isVehicleAvailable(String vehicleId) {
        Vehicle vehicle = getVehicleById(vehicleId);
        return vehicle != null && vehicle.isAvailabilityStatus();
    }
    private boolean updateVehicleAvailability(String vehicleId, boolean status) {
        UpdateResult result = vehicleCollection.updateOne(
                Filters.eq("vehicleId", vehicleId),
                Updates.set("availabilityStatus", status)
        );
        return result.getMatchedCount() > 0;
    }
    private Vehicle getVehicleById(String vehicleId) {
        Document document = vehicleCollection.find(Filters.eq("vehicleId", vehicleId)).first();

        if (document == null) {
            return null;
        }

        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(document.getString("vehicleId"));
        vehicle.setVehicleName(document.getString("vehicleName"));
        vehicle.setVehicleType(document.getString("vehicleType"));
        vehicle.setBrand(document.getString("brand"));
        vehicle.setModel(document.getString("model"));
        vehicle.setPricePerDay(document.getDouble("pricePerDay"));
        vehicle.setAvailabilityStatus(document.getBoolean("availabilityStatus"));
        return vehicle;
    }
    private List<Rental> collectRentals(FindIterable<Document> results) {
        List<Rental> rentals = new ArrayList<>();
        for (Document document : results) {
            rentals.add(documentToRental(document));
        }
        return rentals;
    }
    private Document rentalToDocument(Rental rental) {
        return new Document("rentalId", rental.getRentalId())
                .append("customerId", rental.getCustomerId())
                .append("vehicleId", rental.getVehicleId())
                .append("rentalDate", rental.getRentalDate().toString())
                .append("numberOfDays", rental.getNumberOfDays())
                .append("totalAmount", rental.getTotalAmount())
                .append("rentalStatus", rental.getRentalStatus());
    }
    private Rental documentToRental(Document document) {
        Rental rental = new Rental();
        rental.setRentalId(document.getString("rentalId"));
        rental.setCustomerId(document.getString("customerId"));
        rental.setVehicleId(document.getString("vehicleId"));
        rental.setRentalDate(LocalDate.parse(document.getString("rentalDate")));
        rental.setNumberOfDays(document.getInteger("numberOfDays"));
        rental.setTotalAmount(document.getDouble("totalAmount"));
        rental.setRentalStatus(document.getString("rentalStatus"));
        return rental;
    }
}