package services;

import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import database.MongoConnection;
import models.Vehicle;
import org.bson.Document;
import utils.IDGenerator;
import utils.InputValidator;

import java.util.ArrayList;
import java.util.List;

/**
 * VehicleService
 * --------------
 * Handles all business logic and MongoDB operations related to vehicles.
 * This class is the only place in the application that talks directly
 * to the "vehicles" collection � the Main menu and other services never
 * touch the MongoCollection themselves, they go through these methods.
 *
 * Responsibilities:
 * <ul>
 *     <li>Adding, searching, updating, and deleting vehicle records</li>
 *     <li>Converting between {@link Vehicle} objects and MongoDB {@link Document} objects</li>
 *     <li>Updating availability status when a vehicle is booked or returned</li>
 * </ul>
 */
public class VehicleService{

    private static final String COLLECTION_NAME = "vehicles";
    private final MongoCollection<Document> vehicleCollection;
    public VehicleService() {
        this.vehicleCollection = MongoConnection.getInstance().getDatabase().getCollection(COLLECTION_NAME);
    }
    public boolean addVehicle(Vehicle vehicle) {
        try {
            if (!InputValidator.validatePositiveNumber(vehicle.getPricePerDay())) {
                System.out.println("Invalid price per day. Price must be greater than zero.");
                return false;
            }

            if (vehicle.getVehicleId() == null || vehicle.getVehicleId().trim().isEmpty()) {
                vehicle.setVehicleId(IDGenerator.generateVehicleId());
            }

            Document document = vehicleToDocument(vehicle);
            vehicleCollection.insertOne(document);

            System.out.println("Vehicle added successfully with ID: " + vehicle.getVehicleId());
            return true;

        } catch (MongoException e) {
            System.err.println("Error adding vehicle: " + e.getMessage());
            return false;
        }
    }
    public void viewAllVehicles() {
        try {
            List<Vehicle> vehicles = collectVehicles(vehicleCollection.find());

            if (vehicles.isEmpty()) {
                System.out.println("No vehicles found in the system.");
                return;
            }

            System.out.println("----- All Vehicles -----");
            for (Vehicle vehicle : vehicles) {
                System.out.println(vehicle);
            }

        } catch (MongoException e) {
            System.err.println("Error retrieving vehicles: " + e.getMessage());
        }
    }
    public Vehicle searchVehicleById(String vehicleId) {
        try {
            Document document = vehicleCollection.find(Filters.eq("vehicleId", vehicleId)).first();

            if (document == null) {
                System.out.println("No vehicle found with ID: " + vehicleId);
                return null;
            }

            return documentToVehicle(document);

        } catch (MongoException e) {
            System.err.println("Error searching vehicle by ID: " + e.getMessage());
            return null;
        }
    }
    public List<Vehicle> searchVehiclesByType(String vehicleType) {
        return searchByField("vehicleType", vehicleType);
    }
    public List<Vehicle> searchVehiclesByBrand(String brand) {
        return searchByField("brand", brand);
    }
    public boolean updateVehicle(String vehicleId, Vehicle updatedVehicle) {
        try {
            UpdateResult result = vehicleCollection.updateOne(
                    Filters.eq("vehicleId", vehicleId),
                    Updates.combine(
                            Updates.set("vehicleName", updatedVehicle.getVehicleName()),
                            Updates.set("vehicleType", updatedVehicle.getVehicleType()),
                            Updates.set("brand", updatedVehicle.getBrand()),
                            Updates.set("model", updatedVehicle.getModel()),
                            Updates.set("pricePerDay", updatedVehicle.getPricePerDay()),
                            Updates.set("availabilityStatus", updatedVehicle.isAvailabilityStatus())
                    )
            );

            if (result.getMatchedCount() == 0) {
                System.out.println("No vehicle found with ID: " + vehicleId);
                return false;
            }

            System.out.println("Vehicle updated successfully: " + vehicleId);
            return true;

        } catch (MongoException e) {
            System.err.println("Error updating vehicle: " + e.getMessage());
            return false;
        }
    }
    public boolean deleteVehicle(String vehicleId) {
        try {
            DeleteResult result = vehicleCollection.deleteOne(Filters.eq("vehicleId", vehicleId));

            if (result.getDeletedCount() == 0) {
                System.out.println("No vehicle found with ID: " + vehicleId);
                return false;
            }

            System.out.println("Vehicle deleted successfully: " + vehicleId);
            return true;

        } catch (MongoException e) {
            System.err.println("Error deleting vehicle: " + e.getMessage());
            return false;
        }
    }
    public boolean updateAvailabilityStatus(String vehicleId, boolean status) {
        try {
            UpdateResult result = vehicleCollection.updateOne(
                    Filters.eq("vehicleId", vehicleId),
                    Updates.set("availabilityStatus", status)
            );

            if (result.getMatchedCount() == 0) {
                System.out.println("No vehicle found with ID: " + vehicleId);
                return false;
            }

            System.out.println("Vehicle availability updated: " + vehicleId
                    + " -> " + (status ? "Available" : "Unavailable"));
            return true;

        } catch (MongoException e) {
            System.err.println("Error updating vehicle availability: " + e.getMessage());
            return false;
        }
    }
    private List<Vehicle> searchByField(String fieldName, String value) {
        try {
            List<Vehicle> vehicles = collectVehicles(vehicleCollection.find(Filters.eq(fieldName, value)));

            if (vehicles.isEmpty()) {
                System.out.println("No vehicles found for " + fieldName + ": " + value);
            }

            return vehicles;

        } catch (MongoException e) {
            System.err.println("Error searching vehicles by " + fieldName + ": " + e.getMessage());
            return new ArrayList<>();
        }
    }
    private List<Vehicle> collectVehicles(FindIterable<Document> results) {
        List<Vehicle> vehicles = new ArrayList<>();
        for (Document document : results) {
            vehicles.add(documentToVehicle(document));
        }
        return vehicles;
    }
    private Document vehicleToDocument(Vehicle vehicle) {
        return new Document("vehicleId", vehicle.getVehicleId())
                .append("vehicleName", vehicle.getVehicleName())
                .append("vehicleType", vehicle.getVehicleType())
                .append("brand", vehicle.getBrand())
                .append("model", vehicle.getModel())
                .append("pricePerDay", vehicle.getPricePerDay())
                .append("availabilityStatus", vehicle.isAvailabilityStatus());
    }
    private Vehicle documentToVehicle(Document document) {
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(document.getString("vehicleId"));
        vehicle.setVehicleName(document.getString("vehicleName"));
        vehicle.setVehicleType(document.getString("vehicleType"));
        vehicle.setBrand(document.getString("brand"));
        vehicle.setModel(document.getString("model"));
        vehicle.setPricePerDay(document.getDouble("pricePerDay"));
        vehicle.setAvailabilityStatus(document.getBoolean("availabilityStatus"));
        return vehicle;
    }
}