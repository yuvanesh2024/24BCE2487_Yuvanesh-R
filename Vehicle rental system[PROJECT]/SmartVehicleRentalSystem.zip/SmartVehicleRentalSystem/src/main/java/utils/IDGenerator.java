package utils;

/**
 * IDGenerator
 * -----------
 * Generates unique, human-readable IDs for every entity in the Smart
 * Vehicle Rental Management System.
 *
 * Generated ID formats:
 * <ul>
 *     <li>Admin    ? ADM001, ADM002, ...</li>
 *     <li>Customer ? CUS001, CUS002, ...</li>
 *     <li>Vehicle  ? VEH001, VEH002, ...</li>
 *     <li>Rental   ? REN001, REN002, ...</li>
 *     <li>Payment  ? PAY001, PAY002, ...</li>
 * </ul>
 *
 * All methods are static, so no IDGenerator object ever needs to be
 * created � the class simply keeps an in-memory counter for each
 * entity type for the lifetime of the running application.
 *
 * Note: since this is an in-memory counter (not backed by the database),
 * counters reset to 1 every time the application restarts. For a college
 * project this is acceptable, but in a production system the counters
 * would typically be seeded from the highest existing ID already stored
 * in MongoDB on startup
 */
public class IDGenerator {
    private static int adminCounter = 1;
    private static int customerCounter = 1;
    private static int vehicleCounter = 1;
    private static int rentalCounter = 1;
    private static int paymentCounter = 1;
    private IDGenerator() {
    }
    public static String generateAdminId() {
        String id = "ADM" + formatWithLeadingZeros(adminCounter);
        adminCounter++;
        return id;
    }
    public static String generateCustomerId() {
        String id = "CUS" + formatWithLeadingZeros(customerCounter);
        customerCounter++;
        return id;
    }
    public static String generateVehicleId() {
        String id = "VEH" + formatWithLeadingZeros(vehicleCounter);
        vehicleCounter++;
        return id;
    }
    public static String generateRentalId() {
        String id = "REN" + formatWithLeadingZeros(rentalCounter);
        rentalCounter++;
        return id;
    }
    public static String generatePaymentId() {
        String id = "PAY" + formatWithLeadingZeros(paymentCounter);
        paymentCounter++;
        return id;
    }
    private static String formatWithLeadingZeros(int counter) {
        return String.format("%03d", counter);
    }
}