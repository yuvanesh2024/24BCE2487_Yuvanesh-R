package utils;

import java.util.regex.Pattern;

/**
 * InputValidator
 * --------------
 * Provides static helper methods to validate user input before it is
 * passed to a service class and saved into MongoDB. Centralizing these
 * checks here keeps validation logic out of the service classes and
 * out of the console menu, and avoids duplicating the same regular
 * expressions in multiple places.
 *
 * This class contains no Scanner/console input code and no database
 * logic � it only inspects values it is given and returns true/false
 */
public class InputValidator {
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^[0-9]{10}$");
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$");
    private InputValidator() {
    }
    public static boolean validateEmail(String email) {
        if (email == null) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email.trim()).matches();
    }
    public static boolean validatePhoneNumber(String phoneNumber) {
        if (phoneNumber == null) {
            return false;
        }
        return PHONE_PATTERN.matcher(phoneNumber.trim()).matches();
    }
    public static boolean validatePassword(String password) {
        if (password == null) {
            return false;
        }
        return PASSWORD_PATTERN.matcher(password).matches();
    }
    public static boolean validatePositiveNumber(double number) {
        return number > 0;
    }
    public static boolean validatePositiveInteger(int number) {
        return number > 0;
    }
}